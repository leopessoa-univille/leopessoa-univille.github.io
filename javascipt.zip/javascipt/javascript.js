console.log("Hello World")
var i = 11;
var d = 13.5;
var nome = "Ronaldo";
var ligado = true;

console.log("Nome = " + nome);

//comentário

/*
comentário
*/

//interpolação da string
console.log(`i = ${i}`)
console.log(typeof i)

if(i ==10){
    console.log("i é 10")
}else{
    console.log("i não é 10")
}

// and or
// &&  |

var a = 26;
switch(a){
    case 22:
        console.log("è 22")
        break
    case 21:
        console.log("é 21")
        break
    default:
        console.log("Nenhum dos dois")
        break;
}