//npm install prompt-sync

/*
const prompt = require("prompt-sync")();
const name = prompt("Qual é o seu nome: ");
console.log(name)
*/


// Programa para ler Grau celsius

const prompt = require("prompt-sync")();
const grausC = prompt("Dgite a temperatura em Graus Celsius: ");

var grausF = (9 * grausC + 160)/5

console.log("Temperatura em Graus Fahrenheit: " + grausF)