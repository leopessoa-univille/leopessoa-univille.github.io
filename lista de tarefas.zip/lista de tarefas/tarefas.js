function addTarefa(){
    var tabela = document.getElementById("Tabela");
    
    var inputNome = document.getElementById("inputNome");
    var inputData = document.getElementById("inputData");
    var selectSituacao = document.getElementById("selectSituacao");

    if (inputNome.value.trim() === "") {
        alert("Por favor, digite o nome da tarefa.");
        return;
    }
    var numeroSequencial = tabela.rows.length - 3; 

    // Insere a nova linha e define o ID
    var novaTarefa = tabela.insertRow(-1);
    novaTarefa.id = "linha-" + numeroSequencial;
    
    var celulaNumero = novaTarefa.insertCell(0);
    var celulaNome = novaTarefa.insertCell(1);
    var celulaData = novaTarefa.insertCell(2);
    var celulaSituação = novaTarefa.insertCell(3);

    //Preenche as células com os VALORES digitados nos inputs
    celulaNumero.textContent = numeroSequencial;
    celulaNome.textContent = inputNome.value;
    celulaData.textContent = inputData.value;       
    celulaSituação.textContent = selectSituacao.value;

    //Limpa o campo de texto após adicionar para facilitar a próxima digitação
    inputNome.value = "";
    inputData.value = "";
}
